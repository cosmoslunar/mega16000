Start-Process "appwiz.cpl"
# Start-Process "C:\Path\To\AhnLabRemover.exe" -Verb RunAs